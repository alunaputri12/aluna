<?php
    // admin/footer.php
    if (isset($_SESSION['user_logged_in'])):
?>
</main>
</div>
</div>
<?php
    endif;
?>

<script src="../scripts/jquery-3.7.1.min.js"></script>
<script src="../scripts/bootstrap.bundle.min.js"></script>
</body>

</html>